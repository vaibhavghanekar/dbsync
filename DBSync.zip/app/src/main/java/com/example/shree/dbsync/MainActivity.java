package com.example.shree.dbsync;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    EditText ed_text;
    Button btn_submit;
    RecyclerView rv_view;
    List<TextPOJO> textPOJOList;
    private RecyclerAdapter recyclerAdapter;
    private NetworkAvailability networkAvailability;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ed_text = (EditText) findViewById(R.id.ed_text);
        btn_submit = (Button) findViewById(R.id.btn_submit);
        rv_view = (RecyclerView) findViewById(R.id.rv_view);

        textPOJOList = new ArrayList<>();

        btn_submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String text = ed_text.getText().toString().trim();

                storeToLocalDB(text);
            }
        });

        fetchFromLocalDB();

        networkAvailability = NetworkAvailability.getInstance();
        networkAvailability.registerNetworkAvailability(this, receiver);
    }

    @Override
    protected void onDestroy() {
        networkAvailability.unregisterNetworkAvailability(this, receiver);
        super.onDestroy();
    }

    private BroadcastReceiver receiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (intent.getBooleanExtra(ConnectivityManager.EXTRA_NO_CONNECTIVITY, false)) {
                Toast.makeText(context, "network is not available", Toast.LENGTH_LONG).show();
            } else {
                Toast.makeText(context, "network is available", Toast.LENGTH_LONG).show();
                fetchFromLocalDB();
            }
        }
    };

    private void fetchFromLocalDB() {
        textPOJOList = TextPOJO.listAll(TextPOJO.class);
        Log.d("result_old", textPOJOList.toString());

        if (checkNetWorkConnection()) {
            for (TextPOJO textPOJO : textPOJOList) {
                if (textPOJO.getSyncstatus().equals("n")) {
                    Log.d("result_count", "count100");
                    TextPOJO.findWithQuery(TextPOJO.class, "UPDATE TEXT_POJO SET syncstatus = ? WHERE text = ?", "y", textPOJO.getText());
                    storeToFireBase(textPOJO.getText());
                }
            }
        }

        textPOJOList.clear();
        textPOJOList = TextPOJO.listAll(TextPOJO.class);
        Log.d("result_new", textPOJOList.toString());

        prepareRecyclerView();
    }

    private void prepareRecyclerView() {

        Log.d("result", "2");

        recyclerAdapter = new RecyclerAdapter(textPOJOList);
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(getApplicationContext());
        rv_view.setLayoutManager(layoutManager);
        rv_view.setItemAnimator(new DefaultItemAnimator());
        rv_view.setAdapter(recyclerAdapter);
    }

    private void storeToLocalDB(String text) {
        Log.d("result", "3");

        TextPOJO textPOJO = new TextPOJO();
        textPOJO.setText(text);
        ed_text.setText("");

        if (checkNetWorkConnection()) {
            textPOJO.setSyncstatus("y");
            storeToFireBase(text);
        } else {
            textPOJO.setSyncstatus("n");
            Toast.makeText(this, "No internet connection!", Toast.LENGTH_SHORT).show();
        }

        textPOJO.save();
        textPOJOList.add(textPOJO);
        recyclerAdapter.notifyDataSetChanged();
    }

    private void storeToFireBase(String text) {
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference(text + "_key");

        myRef.setValue(text);
    }

    public boolean checkNetWorkConnection() {
        ConnectivityManager connectivityManager = (ConnectivityManager) this.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();
        return (networkInfo != null && networkInfo.isConnected());
    }
}
