package com.example.shree.dbsync;

import com.orm.SugarRecord;

public class TextPOJO extends SugarRecord<TextPOJO> {
    private String text;
    private String syncstatus;


    @Override
    public String toString() {
        return "TextPOJO{" +
                "text='" + text + '\'' +
                ", syncstatus='" + syncstatus + '\'' +
                '}';
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public String getSyncstatus() {
        return syncstatus;
    }

    public void setSyncstatus(String syncstatus) {
        this.syncstatus = syncstatus;
    }

    public TextPOJO() {
    }

    public TextPOJO(String text, String syncstatus) {
        this.text = text;
        this.syncstatus = syncstatus;
    }
}