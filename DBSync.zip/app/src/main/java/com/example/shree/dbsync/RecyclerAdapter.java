package com.example.shree.dbsync;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

public class RecyclerAdapter extends RecyclerView.Adapter<RecyclerAdapter.MyViewHolder> {

    private List<TextPOJO> textPOJOList;

    public RecyclerAdapter(List<TextPOJO> textPOJOList) {
        this.textPOJOList = textPOJOList;
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        public TextView tv_text;
        public ImageView img_tick, img_cross;

        public MyViewHolder(View itemView) {
            super(itemView);

            tv_text = (TextView) itemView.findViewById(R.id.tv_text);
            img_tick = (ImageView) itemView.findViewById(R.id.img_tick);
            img_cross = (ImageView) itemView.findViewById(R.id.img_cross);
        }
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.recyclerview_row, parent, false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, int position) {
        TextPOJO textPOJO = textPOJOList.get(position);
        holder.tv_text.setText(textPOJO.getText());
        if (textPOJO.getSyncstatus().equals("y")) {
            holder.img_tick.setVisibility(View.VISIBLE);
            holder.img_cross.setVisibility(View.GONE);
        } else {
            holder.img_cross.setVisibility(View.VISIBLE);
            holder.img_tick.setVisibility(View.GONE);
        }

    }

    @Override
    public int getItemCount() {
        return textPOJOList.size();
    }
}